The Dining Philosopher Problem
For windows only

The program requires JDK 1.6.0 or higher. Please install JDK
by running 'jdk-6-windows.exe' in the current directory.
